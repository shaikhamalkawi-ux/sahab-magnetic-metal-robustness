# Sahab V34 — Public reproducibility archive (GitHub-only)

**Research paper:** Robustness of Magnetic Susceptibility–Metal Associations to Iron Adjustment and Chemical Target Definition: Evidence from Sahab Urban Soils.

**Authors (manuscript order):** Mahdi Salem Lataifeh; Tayel Mahmoud El-Hasan; Abdel-Jaleel Al-Nawiseh; Ghassan Malkawi (corresponding author); Ahmed Elsayed.

**Status:** Reproducibility deposit for a manuscript prepared for *Environments*. This deposit does **not** indicate acceptance or publication. The analysis is retrospective, not prospective fieldwork. Scientific baseline V34 is unchanged.

## Primary inputs
- `Sahab48_primary.csv`: 48 source-reconciled observations used in the principal analysis; these are **not all 56** historical magnetic rows. Of 56, 54 historical chemistry identities were resolved; two remained unresolved; the principal tolerance retained 48.
- `Amman44_primary.csv`: 44 Amman–Airport comparison records, distinct measurement methods and sampling from Sahab; no study pooling.
- `Zagreb25_primary.csv`: 25 matched surface-location values transcribed from a CC BY 4.0 article; deep-only samples excluded. See `docs/SOURCE_RIGHTS_AND_CROSSWALK.md`.
- `evidence/Sahab_DataRecovery_and_Reconciliation.xlsx`: historical source-reconciliation workbooks and source record status.

The `data_confidential/` directory is the **unchanged directory name required by the original V34 scripts**. In this GitHub copy, the included files are publicly supplied for reproducibility; the directory name does not indicate an access restriction. Root-level input CSV duplicates are byte-identical and are required by the historic runner.

## Scientific methods and bounded claims
`N4={Mn,Cu,Ni,Zn}` and `N5=N4+Pb` refer to sets of chemical components. Complete finite-sample Fe-adjusted correlation intervals refer to recorded observations and admitted nonnegative additive weights. They do not supply population bounds, causal Fe-source separation, present-day contamination classifications, spatial validation, prospective predictive accuracy, or instrument superiority. Repeated random held-out splits are exploratory stability diagnostics only.

The frozen numeric reference summaries and split-level results are provided under `results/`. No original numeric result was retuned, reweighted, or changed for this release.

## Reproduction
Python 3.13 and NumPy, SciPy, pandas. The original dependencies are in `requirements.txt`.

```bash
python -m pip install -r requirements.txt
PYTHONDONTWRITEBYTECODE=1 python code/verify_v34.py
python verify_release.py
```

The first command checks **80 independent multistart SLSQP comparisons** and **byte-equivalent replay** of the five key held-out files in the original V34 protocol. The second validates the release SHA-256 file inventory. These are numerical diagnostics, not rational-arithmetic certificates. Other drivers are preserved under `code/` to generate all published V34 scenarios and sensitivity variants.

## Dataset difference requiring provenance care
The sample-8 fine-frequency value in the frozen V34 Amman input is `246.05`. An **independently reconstructed master** in the existing public `shaikhamalkawi-ux/amman-airport-magnetic-screening` repository reports approximately `224.390243902439` for sample 8 and documents a different fine-mass treatment. Do not silently substitute one master for the other; see `docs/SOURCE_RIGHTS_AND_CROSSWALK.md`. The present release contains the **original V34 input, unmodified**.

## Release rights and citation
Public availability is based on the submitter's confirmation of coauthor consent. Sources and third-party licensing are not conflated: Zagreb published data are adapted from CC BY 4.0 and must retain attribution. Publication here does **not** assert that every individual source-derived table or document is newly licensed CC BY or MIT; see `docs/SOURCE_RIGHTS_AND_CROSSWALK.md` for scope and open rights documentation items. Cite the underlying surveys/studies in addition to this repository.

**DOI:** none assigned. **Zenodo:** deliberately postponed until journal acceptance at the user's request.
