# Executable verification — public Sahab/Amman, Zagreb results only

The V34 source artifacts were recovered from the previously validated original internal archive. The original complete dataset (including Zagreb) was verified **before selective disclosure** with 80/80 SLSQP checks, five matched frozen held-out output files and a 54/54 manifest. Those *historical archive results* remain locked, and the original `results/` directory has not been retuned or regenerated for this selective public release.

This public release intentionally omits both occurrences of the `Zagreb25_primary.csv` numerical observation table. Therefore `code/verify_v34.py` and other complete all-cohort runners are **not executable from this public archive alone**. A separate public-source verifier was added: `code/verify_public_sahab_amman.py`. With the dependencies from `requirements.txt`, run:

```sh
python verify_release.py
PYTHONDONTWRITEBYTECODE=1 python code/verify_public_sahab_amman.py
```

The available-data verification checks exactly **40 Sahab/Amman SLSQP optimizations**, four 2,000-split CSV replays and the local checksum manifest; it reports both counts explicitly. It does not silently skip Zagreb and describe the result as full V34 numerical verification. The derived Zagreb summary and split-level results are retained without the row-level source data. To reproduce the Zagreb computations, consult the original public article (Table 10, Appendix A), perform a fresh independent transcription, and run the original scripts with an appropriately named user-provided input. Site-selection and source-definition details are in the cited article and `docs/SOURCE_RIGHTS_AND_CROSSWALK.md`.

The code still lists the Zagreb input filenames because the original scientific analysis includes Zagreb, not because those files are redistributed here. Archived numerical results are empirical, not prospective or spatial validation.
