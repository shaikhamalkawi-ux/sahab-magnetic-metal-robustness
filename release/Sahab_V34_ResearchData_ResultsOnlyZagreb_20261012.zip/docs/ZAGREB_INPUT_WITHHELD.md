# Zagreb sample-level observations excluded

The depositor requests non-redistribution of Zagreb's published chemical and magnetic measurement table. This public release therefore contains **no Zagreb source-level observation matrix**. Original article: Frančišković-Bilinski et al. (2023), *Magnetic and geochemical properties of Zagreb city area soils*, *Minerals* 13, 1481. https://doi.org/10.3390/min13121481.

Only the originally calculated V34 statistical and split-level **results** are retained. The previous full-data numerical verification (80 SLSQP / five primary byte-identical replays) is historical evidence of the original complete internal archive, not a test that can be run from the restricted present GitHub release without retrieving source data independently.

No empirical inputs are changed, and none is fabricated to fill the missing table. The publication decision is about redistribution, not permission to cite or statistically analyze previously published results.
