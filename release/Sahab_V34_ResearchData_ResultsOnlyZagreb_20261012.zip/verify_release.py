#!/usr/bin/env python3
"""Check SHA-256 hashes of all payload files in the Sahab V34 GitHub release."""
import hashlib,pathlib,sys
r=pathlib.Path(__file__).resolve().parent
lines=(r/'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines()
fail=[]
for line in lines:
  if not line.strip():continue
  h, f = line.split('  ',1)
  p=(r/f).resolve()
  if not p.is_relative_to(r.resolve()) or not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=h:
    fail.append(f)
print(f'Sahab V34 GitHub release manifest: {len(lines)-len(fail)}/{len(lines)} PASS')
if fail:
  print('MISMATCH:',*fail,sep='\n');sys.exit(1)
