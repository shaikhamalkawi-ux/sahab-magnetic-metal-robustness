# Sahab V34 — Public research data with Zagreb results only (GitHub)

**Paper:** Robustness of Magnetic Susceptibility–Metal Associations to Iron Adjustment and Chemical Target Definition: Evidence from Sahab Urban Soils.  
**Authors:** Mahdi Salem Lataifeh; Tayel Mahmoud El-Hasan; Abdel-Jaleel Al-Nawiseh; Ghassan Malkawi (corresponding); Ahmed Elsayed.  
**Version:** original scientific baseline V34, no scientific recalculations or changes. **Journal:** Environments (MDPI), not yet accepted.

## Data and outcomes published here

- `Sahab48_primary.csv` — exact original 48 analytical sample records (56 historical measurements, 54 sample identities reconciled; not a new field campaign).
- `Amman44_primary.csv` — exact original 44 source-derived Amman–Airport comparison observations (not pooled with Sahab).
- `data_confidential/` — copies of only the Sahab and Amman originals, retaining the historical folder name required by the scripts. The present copies are public.
- `evidence/Sahab_DataRecovery_and_Reconciliation.xlsx` — historic reconciliation workbook.
- `results/` — frozen, **derived** V34 results for all three studies, including Zagreb N4/N5 held-out split diagnostics, channel-comparison results, simulations, numerical verification and summary outputs. Zagreb result files do not contain its source observation table.
- `code/` — original methodology and reproducibility scripts, unchanged, plus a separate *new* available-data verification script.

### Zagreb exception — NO sample-level source redistribution

The Zagreb 25-site published-table transcription and per-site chemical/magnetic observation matrix are **not** included anywhere in this ZIP. They were withdrawn at the user's request. Zagreb's **derived statistical outputs** remain, and all original analyses/figures/conclusions remain numerically unchanged. Independent readers can consult the authors' original publication: Frančišković-Bilinski et al. (2023), *Minerals* 13, 1481, https://doi.org/10.3390/min13121481, which contains Table 10 and Appendix A. We do not provide a substitute/transcription or a synthetic replacement.

The Zagreb results cannot be independently recomputed from this archive **alone**. Full original `code/verify_v34.py` needs the separately sourced Zagreb observation table; use the available-data verifier below instead. The historical 80-case / five-output replay was passed on the original internal archive **before the removal**; that is not a new public-data replay claim. Do not cite the older all-data ZIP as the current public release.

## Verify the public records and exact Sahab/Amman analyses

From an extracted copy of this ZIP, with Python and dependencies in `requirements.txt` installed:

```sh
python verify_release.py
PYTHONDONTWRITEBYTECODE=1 python code/verify_public_sahab_amman.py
```

The first command verifies every SHA-256 listed in this **new** release manifest. The second independently compares the optimization algorithm to multistart SLSQP on the accessible Sahab/Amman data and checks that the four N4/N5 2,000-split result CSVs reproduce the frozen original outputs byte-for-byte. It does **not** purport to verify Zagreb data without those observations. The original full verifier is preserved only for users independently supplying the original Zagreb input in the required locations.

## Data provenance, reuse rights and interpretation

Zagreb source: CC BY 4.0 underlying publication, properly cited; this release does not redistribute its numeric observation matrix. The current manuscript authors confirm approval to make Sahab and Amman analytic data available. Third-party source rights are not silently overwritten by an all-files license. The Amman sample-8 fine-frequency value differs from another independently reconstructed master (locked V34 246.05 vs about 224.390243902439), as documented in `docs/SOURCE_RIGHTS_AND_CROSSWALK.md`. V34 keeps its original input unchanged.

The V34 outcomes are fixed-sample and exploratory split diagnostics; they do not establish population robustness, spatial transfer, causal source identification, present-day contamination, prediction accuracy or instrument superiority. **No Zenodo DOI is assigned for this Sahab archive; Zenodo is postponed until journal acceptance.**
